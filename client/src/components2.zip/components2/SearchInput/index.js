import React from "react"


function SearchInput() {
    return (

<div className="input-group flex-nowrap">
  <div className="input-group-prepend">
    
  </div>
  <input type="text" className="form-control" placeholder="Username" aria-label="Username" aria-describedby="addon-wrapping"/>
  
</div>

    )
}


export default SearchInput;